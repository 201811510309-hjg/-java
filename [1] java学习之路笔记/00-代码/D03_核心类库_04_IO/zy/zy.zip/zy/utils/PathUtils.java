package D03_核心类库_04_IO.zy.utils;

import javax.servlet.http.HttpServletRequest;

public class PathUtils {
	/**
	 * 返回域名 + contextPath 
	 * @param request
	 * @return
	 */
	public static String getURLFullPath(HttpServletRequest request){
		return request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()
		+ request.getContextPath(); 
	}
}
