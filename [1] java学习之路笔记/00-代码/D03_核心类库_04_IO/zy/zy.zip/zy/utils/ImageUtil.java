package D03_核心类库_04_IO.zy.utils;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

public class ImageUtil {
		//判断是否为图片格式
		public static String getFormatName(Object o) {
			try {
			    // Create an image input stream on the image
				ImageInputStream iis = ImageIO.createImageInputStream(o);
			    // Find all image readers that recognize the image format
				Iterator iter = ImageIO.getImageReaders(iis);
			 if (!iter.hasNext()) {
			 // No readers found
				 return null;
			 }
			 // Use the first reader
			 ImageReader reader = (ImageReader) iter.next();
			 // Close stream

			 iis.close();
			 // Return the format name

			 	return reader.getFormatName();
			 } catch (IOException e) {
				 return null;
			 }
			 // The image could not be read		 		
		}
}
