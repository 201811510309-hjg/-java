package D03_核心类库_04_IO.zy.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DateUtils {
	/**
	 * yyyy-MM-dd hh:mm:ss
	 */
	public static String DEFAULT_LONGDATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	/**
	 * yyyy-MM-dd hh:mm
	 */
	public static String DEFAULT_DATE_WITH_HM_FORMAT = "yyyy-MM-dd HH:mm";
	
	/**
	 * yyyy-MM-dd
	 */
	public static String DEFAULT_SHORTDATE_FORMAT = "yyyy-MM-dd";

	/**
	 * yyyyMMdd
	 */
	public static String SHORT_DATE_FORMAT = "yyyyMMdd";

	/**
	 * 计算2个日期相差的天数，但是可能为正，也可能为负数
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public static long getDaysBetween(Date beginDate,Date endDate)
    {                                      
//         return (endDate.getTime() - beginDate.getTime())/(24*60*60*1000);
		return ( (beginDate.getTime() -endDate.getTime())*10)/(24*60*60*1000);
    }
	
	/**
	 * 计算一个date 添加 month 个月后得到的 date 结果
	 * 
	 * @param date
	 * @param month
	 *            要添加的月数
	 * @return
	 */
	public static Date addMonth(Date date, int month) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.set(Calendar.MONTH, c.get(Calendar.MONTH) + month);
		return c.getTime();
	}

	public static Date addMonth(Date date, int month, int day) {
		Calendar c = Calendar.getInstance();
		c.setTime(addMonth(date, month));
		c.set(Calendar.DATE, c.get(Calendar.DATE) + day);
		return c.getTime();
	}

	/**
	 * 计算两个日期相差的天数
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static long intervalDate(Date startDate, Date endDate) {
		long intervalDay = 0L;
		try {
			if (endDate.after(startDate)) {
				intervalDay = endDate.getTime() - startDate.getTime();
			} else {
				intervalDay = startDate.getTime() - endDate.getTime();
			}
			intervalDay = (intervalDay / 1000 / 60 / 60 / 24) + 1;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return intervalDay;
	}

	/**
	 * 遍历得到时间段的时间列表
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static List<Date> iterateDate(Date startDate, Date endDate) {
		List<Date> dateList = new ArrayList<Date>();
		try {
			Calendar c1 = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();
			c1.setTime(startDate);
			c2.setTime(endDate);
			while (c1.before(c2)) {
				dateList.add(c1.getTime());
				c1.add(Calendar.DATE, 1);
			}
			dateList.add(endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateList;
	}

	/**
	 * 得到日期为星期几
	 * 
	 * @param data
	 * @return
	 */
	public static String getDayOfWeek(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int weekDay = calendar.get(Calendar.DAY_OF_WEEK);
		String result = "";
		switch (weekDay) {
		case Calendar.MONDAY:
			result = "周一";
			break;
		case Calendar.TUESDAY:
			result = "周二";
			break;
		case Calendar.WEDNESDAY:
			result = "周三";
			break;
		case Calendar.THURSDAY:
			result = "周四";
			break;
		case Calendar.FRIDAY:
			result = "周五";
			break;
		case Calendar.SATURDAY:
			result = "周六";
			break;
		case Calendar.SUNDAY:
			result = "周日";
			break;
		default:
			break;
		}
		return result;
	}
	
	/**
	 * 判断两个日期是否为同一天
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean equalSameDay(Date date1,Date date2){
		String strDate1 = getShortDateStr(date1);
		String strDate2 = getShortDateStr(date2);
		if(strDate1.equals(strDate2)){
			return true;
		}else {
			return false;
		}
	}

	public static Date getFormatDate(String str, String format) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date d = new Date();
			d = sdf.parse(str);
			return d;
		} catch (Exception e) {

		}
		return null;
	}
	
	 
	/**
	 * 
	 * @param str
	 * @return 将日期str yyyy-MM-dd转成日期
	 */
	public static Date parseShortDate(String str) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(
					DEFAULT_SHORTDATE_FORMAT);
			Date d = new Date();
			d = sdf.parse(str);
			return d;
		} catch (Exception e) {

		}
		return null;
	}
	
	/**
	 * 把格式 yyyy-MM-dd hh:mm日期转成date
	 * @param str
	 * @return
	 */
	public static Date parseShortDateHM(String str) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(
					DEFAULT_DATE_WITH_HM_FORMAT);
			Date d = new Date();
			d = sdf.parse(str);
			return d;
		} catch (Exception e) {

		}
		return null;
	}
	
	

	/**
	 * 
	 * @param str
	 * @return 将格式日期str yyyy-MM-dd hh:mm:ss转成日期
	 */
	public static Date parseLongDate(String str) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_LONGDATE_FORMAT);
			Date d = new Date();
			d = sdf.parse(str);
			return d;
		} catch (Exception e) {

		}
		return null;
	}

	/**
	 * 
	 * @return 以格式yyyy-MM-dd hh:mm:ss返回当前日期
	 */
	public static String getCurrentDateStr() {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_LONGDATE_FORMAT);
			Calendar cal = Calendar.getInstance();
			ret = sdf.format(cal.getTime());
			return ret;
		} catch (Exception e) {

		}
		return ret;

	}

	/**
	 * 
	 * @param date
	 * @return yyyy-MM-dd hh:mm:ss格式的日期
	 */
	public static String getDateStr(Date date) {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_LONGDATE_FORMAT);
			ret = sdf.format(date);
			return ret;
		} catch (Exception e) {

		}
		return ret;
	}

	/**
	 * 
	 * @param date
	 * @return yyyy-MM-dd格式的日期
	 */
	public static String getShortDateStr(Date date) {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(
					DEFAULT_SHORTDATE_FORMAT);
			ret = sdf.format(date);
			return ret;
		} catch (Exception e) {

		}
		return ret;
	}
	
	/**
	 * 
	 * @param date
	 * @return yyyy-MM-dd hh:mm格式的日期
	 */
	public static String getDateStrWithHM(Date date) {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(
					DEFAULT_DATE_WITH_HM_FORMAT);
			ret = sdf.format(date);
			return ret;
		} catch (Exception e) {

		}
		return ret;
	}
	
	/**
	 * 
	 * @param date
	 * @return M/d日  hh:mm  格式的日期
	 */
	public static String getDateStrWithHMChinese(Date date) {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("M/d HH:mm");
			ret = sdf.format(date);			 
			return ret;
		} catch (Exception e) {

		}
		return ret;
	}

	/**
	 * 
	 * @return 以yyyyMMdd格式返回服务器当前日期
	 */
	public static String getCurDateStr() {
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(SHORT_DATE_FORMAT);
			ret = sdf.format(new Date());
			return ret;
		} catch (Exception e) {

		}
		return ret;

	}
	
	/**
	 * 
	 * @param date
	 * @return 以yyyy.MM.dd格式返回日期
	 */
	public static String getDotDateStr(Date date){
		String ret = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
			ret = sdf.format(date);
			return ret;
		} catch (Exception e) {

		}
		return ret;
	}
	
	/**
	 * 
	 * @param date
	 * @return 以yyyy.MM.dd HH:mm格式返回日期
	 */
	public static String getDotLongDateStr(Date date){
		String ret = "";
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm");
			ret = sdf.format(date);
			return ret;
		}catch(Exception e){
			
		}
		return ret;
	}
	
	/**
	 * 
	 * @param date
	 * @return HH:mm格式返回小时和分钟
	 */
	public static String getHourMinteStr(Date date){
		String ret = "";
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			ret = sdf.format(date);
			return ret;
		}catch(Exception e){
			
		}
		return ret;
	}


	public static String getShortDateChineseStr(Date eventDate) {
		String[] str = getShortDateStr(eventDate).split("-");
		 
		return str[0] + "年" + str[1] + "月" + str[2] + "日";
	}
	
	public static void main(String[] args) {		 
		System.out.println(getDateStrWithHMChinese(new Date()));
	}
}
