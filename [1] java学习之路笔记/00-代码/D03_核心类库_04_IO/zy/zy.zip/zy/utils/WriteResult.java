package D03_核心类库_04_IO.zy.utils;

import java.io.IOException;
import java.io.Writer;
 
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

public class WriteResult {
	public static void writeJsonStr(String text,HttpServletResponse response)
	  {
	    try
	    {
	      response.setContentType("text/json;charset=utf-8");	    
	      Writer writer = response.getWriter();
	      writer.write(text);
	      writer.flush();
	      writer.close();
	    } catch (IOException e) {
	    	 
	    }
	  }
	
	public static void writeJson(Object obj,HttpServletResponse response){
		 JsonConfig config = new JsonConfig();
		 //config.registerJsonValueProcessor(String.class, new StringJsonValueProcessor());
		 config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor(DateUtils.DEFAULT_LONGDATE_FORMAT));
		 writeJsonStr(JSONObject.fromObject(obj, config).toString(),response);
	 }

	 
	 public static void writeBasicResult(HttpServletResponse response,boolean result,String message){
		HashMap<String, String>	rlt = new HashMap<String, String>();
		rlt.put("result", result?"true":"false");
		rlt.put("message", message);
		writeJson(rlt,response);
	 }
	 public static void writeJsonArray(Object obj,HttpServletResponse response){
		 JsonConfig config = new JsonConfig();
		 config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor(DateUtils.DEFAULT_LONGDATE_FORMAT));
		 writeJsonStr(JSONArray.fromObject(obj, config).toString(),response);
	 }
	 
	
}



class StringJsonValueProcessor implements JsonValueProcessor{

	@Override
	public Object processArrayValue(Object arg0, JsonConfig arg1) {		 
		if (arg0 instanceof String[]) {	
			String[] obj = {};
			String[] dates = (String[]) arg0;
			obj = new String[dates.length];
			for (int i = 0; i < dates.length; i++) {
				obj[i] = (String)dates[i] == null?"":(String)dates[i];
			}
			return obj;
		}
		else
			return arg0;
	}

	@Override
	public Object processObjectValue(String arg0, Object arg1, JsonConfig arg2) {
		return (String)arg1 == null?"":(String)arg1;
	}
	
}

