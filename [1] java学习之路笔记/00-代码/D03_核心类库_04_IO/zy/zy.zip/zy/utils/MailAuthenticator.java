package D03_核心类库_04_IO.zy.utils;

import javax.mail.*;

public class MailAuthenticator extends Authenticator{
	  String userName=null;   
	    String password=null;   
	        
	    public MailAuthenticator(){   
	    }   
	    public MailAuthenticator(String username, String password) {    
	        this.userName = username;    
	        this.password = password;    
	    }    
	    protected PasswordAuthentication getPasswordAuthentication(){   
	        return new PasswordAuthentication(userName, password);   
	    }   
	}  
