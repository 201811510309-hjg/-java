package D03_核心类库_04_IO.zy.utils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.commons.lang.builder.ToStringBuilder;

public class StringUtils {
	private static final char SEPARATOR = '_';

	public static String toCamelCase(String s) {
		if (s == null) {
			return null;
		}
		s = s.toLowerCase();
		StringBuilder sb = new StringBuilder(s.length());
		boolean upperCase = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == SEPARATOR) {
				upperCase = true;

			} else if (upperCase) {
				sb.append(Character.toUpperCase(c));
				upperCase = false;

			} else {
				sb.append(c);
			}
		}
		return sb.toString();

	}
    
	/**
	 * 
	 * @param value
	 * @return null when value is null or ""
	 */
	public static String toString(String value){
		return (value == null || value.length() == 0)?null:value;
	}
	
	/**
	 * 判断是不是null 或 空串
	 * @param value
	 * @return
	 */
	public static boolean isEmpty(String value){
		return null == value || "".equals(value);
	}
	
	
	/**
	 * 
	 * @param value
	 * @return null when value is null or ""
	 */
	public static Long toLong(String value){
		return (value == null || value.length() == 0)?null:Long.parseLong(value);
	}
	
	/**
	 * 将纯文本中的换行符换成html中的换行符
	 * @param string
	 * @return
	 */
	public static String toHtmlFormatStr(String string){
		return null != string ? string.replaceAll("(\r\n|\r|\n|\n\r)", "<br />&nbsp;&nbsp;&nbsp;&nbsp;"):null;
	}
	
	public static String convertStreamToString(InputStream is,String charsetName)  
            throws UnsupportedEncodingException {  
        BufferedInputStream bis = new BufferedInputStream(is);  
        InputStreamReader inputStreamReader = new InputStreamReader(bis, charsetName);  
        BufferedReader br = new BufferedReader(inputStreamReader);  
        StringBuilder sb = new StringBuilder();  
        String line = null;  
        try {  
            while ((line = br.readLine()) != null) {  
                sb.append(line);  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        } finally {  
            try {  
                is.close();  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
        }  
        return sb.toString();  
    }  
	
	
	
	
	public static void main(String[] args){
		System.out.println(StringUtils.toCamelCase("hotel_commenT"));
	}
	
}
