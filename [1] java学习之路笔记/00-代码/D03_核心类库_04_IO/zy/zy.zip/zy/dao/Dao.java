package D03_核心类库_04_IO.zy.dao;


import D03_核心类库_04_IO.zy.bean.Express;
import D03_核心类库_04_IO.zy.utils.FileUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Dao {
    FileUtils file;
    //创建集合对象
    private List<Express> list = new ArrayList<>();

    public void setList(List<Express> list) {
        this.list = list;
    }

    //数据录入
    public boolean insert(Express e) throws IOException {
        //判断
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\b.txt"))){
            list =(ArrayList<Express>) ois.readObject();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getId() == e.getId() ){
                    System.out.println("快递已存在请重新输入");
                }else {
                    list.add(e);
                    file.ObjectOutputMethod((ArrayList<Express>) list);
                    return true;
                }
            }
            ois.close();
        } catch (IOException | ClassNotFoundException e1) {
            //添加到集合中
            list.add(e);
            ObjectOutputStream bw = new ObjectOutputStream(new FileOutputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
            bw.writeObject(list);
            bw.close();
            System.out.println("写入成功");
            return true;
        }
        return false;

    }
    //删除数据
    public boolean delete(Express e) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
        list = (ArrayList<Express>)ois.readObject();
        boolean remove = list.remove(e);
        ObjectOutputStream bw = new ObjectOutputStream(new FileOutputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
        bw.writeObject(list);
        bw.close();
        ois.close();
        return  remove;
    }
    //修改
    public boolean update(Express e1,Express e2) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
        //读取文件
        list =(ArrayList<Express>) ois.readObject();
        //删除旧的
        list.remove(e1);
        //添加新的
        list.add(e2);

        ObjectOutputStream bw = new ObjectOutputStream(new FileOutputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
        bw.writeObject(list);
        bw.close();
        ois.close();
        System.out.println("修改成功");
        return true;
    }
    //查询所有数据
    public List<Express> getList() throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\IdeaProjects\\basic-code\\day21-code-Express\\a.txt"));
        list = (ArrayList<Express>)ois.readObject();
        if (list == null)
            return null;
        ois.close();
        return list;
    }
    //数据查询，根据快递单号查询
    public Express getByNumber(String number){
        //增强for循环
        for (Express e:list){
            if (number.equals(e.getId())){
                return e;
            }
        }
        return null;
    }
    //数据查询，根据取件码查询
    public Express getByCode(int code){
        //遍历获取集合中所有元素，拿集合中的取件码和输入的取件对比
        for (Express e:list){
            if (e.getCode() == code){
                return e;
            }
        }
        return null;
    }
    //获取位置
    public int getIndex(Express e){
        return list.indexOf(e)+1;
    }
}


