package D03_核心类库_04_IO.zy2;

import java.io.IOException;
import java.util.Scanner;
import java.util.Set;
public class view {
    static Express e = new Express();
    static Scanner input = new Scanner(System.in);

    void welcome() {
        System.out.println("------欢迎登入快递驿站-------");
    }

    int menu() {
        System.out.println("请选择你的身份 1.快递管理员 2.用户 0.退出主菜单");
        Scanner input = new Scanner(System.in);
        String choose = input.nextLine();
        int i = 0;
        try {
            i = Integer.valueOf(choose).intValue();
        } catch (NumberFormatException e) {
            System.out.println("输入的不是数字请重新输入");
            return menu();
        }
        if (i > 2 || i < 0) {
            System.out.println("输入的范围错误请重新输入");
            return menu();
        }
        return i;
    }

    int managementMenu() {
        System.out.println("请输入要使用的功能");
        System.out.println("1.增加快递 2.删除快递");
        System.out.println("3.修改快递 4.查看所有快递");
        System.out.println("5.返回主菜单");
        Scanner input = new Scanner(System.in);
        String choose = input.nextLine();
        int i = 0;
        try {
            i = Integer.valueOf(choose).intValue();
        } catch (NumberFormatException e) {
            System.out.println("输入的不是数字请重新输入");
            return managementMenu();
        }
        if (i > 6 || i < 1) {
            System.out.println("输入的范围错误请重新输入");
            return managementMenu();
        }
        return i;
    }

    int user() throws IOException {
        System.out.println("请输入取件码");
        Scanner input = new Scanner(System.in);
        String numbers = input.nextLine();
        int i = Integer.valueOf(numbers).intValue();
        /*try {
            i = Integer.valueOf(numbers).intValue();
        } catch (NumberFormatException e) {
            System.out.println("输入的不是数字请重新输入");
            return user();
        }
        if (i > 999999 || i < 100000) {
            System.out.println("输入的范围错误请重新输入");
            return user();
        }*/
        Set<Integer> set = e.map.keySet();
        Integer number1 = new Integer(numbers);
        for (Integer key : set) {
            if (e.number.get(key) == number1) {
                System.out.println("订单号为" + key + "，公司为" + e.map.remove(key));
                e.map.remove(key);
                Serializable.MySerializable(e);
                System.out.println("序列化成功");
            }
        }
        return 0;
    }
    /*
    1.增加快递
     */
    void save() throws IOException {
        System.out.println("请输入订单号");
        Scanner input=new Scanner(System.in);
        String code=input.nextLine();
        int i=0;
        try {
            i=Integer.valueOf(code).intValue();
        } catch (NumberFormatException numberFormatException) {
            System.out.println("输入的不是数字请重新输入");
            save();
        }
        String judge=e.map.get(i);
        if(judge==null) {
            System.out.println("请输入公司名称");
            String company = input.nextLine();
            e.map.put(i, company);
            e.number.put(i, e.getNumber());
            System.out.println("存人成功！");
            Serializable.MySerializable(e);
            System.out.println("序列化成功");
        }else {
            System.out.println("已经有快递在该快递柜中请重新输入");
            save();
        }
    }
    /*
    2.删除快递
     */
    void delete() throws IOException {
        System.out.println("请输入要删除的订单号");
        String code=input.nextLine();
        int i=0;
        try {
            i=Integer.valueOf(code).intValue();
        } catch (NumberFormatException numberFormatException) {
            System.out.println("输入的不是数字请重新输入");
            delete();
        }
        String c=e.map.remove(i);
        if(c!=null){
            e.number.remove(i);
            System.out.println("删除成功");
            Serializable.MySerializable(e);
            System.out.println("序列化成功");
        }
        else
            System.out.println("此快递单号没有快递");
    }
    /*
    3.修改快递
     */
    void correction() throws IOException {
        System.out.println("请选择你要修改的快递单号");
        String code=input.nextLine();
        int i=0;
        try {
            i=Integer.valueOf(code).intValue();
        } catch (NumberFormatException numberFormatException) {
            System.out.println("输入的不是数字请重新输入");
            correction();
        }
        String c=e.map.remove(i);
        if(c!=null){
            e.number.remove(i);
            Serializable.MySerializable(e);
            System.out.println("序列化成功");
        }
        else {
            System.out.println("此快递单号没有快递,请重新输入");
            correction();
        }
        save();
        System.out.println("修改成功");
    }
    /*
    4.查看所有快递
     */
    void chockAll() throws IOException, ClassNotFoundException {
        Express o= (Express) Serializable.MyDeserializable(e);
        System.out.println("反序列化完成");
        e.map=o.map;
        e.number=o.number;
        Set<Integer> set = o.map.keySet();
        for (Integer key : set) {
            System.out.println("订单号为" + key + "，公司为" + o.map.get(key));
            System.out.println("取件码为" + o.number.get(key));
        }
    }

    void bye(){
        System.out.println("感谢您的使用，欢迎下次再来");
    }

}
