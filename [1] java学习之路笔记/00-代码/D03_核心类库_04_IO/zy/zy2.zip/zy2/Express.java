package D03_核心类库_04_IO.zy2;

import java.util.HashMap;
import java.util.Random;

public class Express implements java.io.Serializable{

    HashMap<Integer,String> map=new HashMap<>();
    HashMap<Integer,Integer> number=new HashMap<>();

    @Override
    public String toString() {
        return "Express{" +
                "map=" + map +
                ", number=" + number +
                '}';
    }

    public Integer getNumber() {
        Random random=new Random();
        int number=random.nextInt(899999)+100000;
        Integer number1 = new Integer(number);
        //int number1 = 111111;
        return number1;
    }


}
