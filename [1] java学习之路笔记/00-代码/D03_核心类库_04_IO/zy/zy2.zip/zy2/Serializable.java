package D03_核心类库_04_IO.zy2;

import java.io.*;

public class Serializable {

    public static void MySerializable(Express e) throws IOException {
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("Express.txt"));
        oos.writeObject(e);
        oos.close();
    }
    public static Object MyDeserializable(Express map1) throws IOException, ClassNotFoundException {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream("Express.txt"));
        Object o=  ois.readObject();
        return o;
    }

}
