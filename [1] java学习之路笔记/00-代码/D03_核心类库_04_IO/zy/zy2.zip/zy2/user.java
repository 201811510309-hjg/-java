package D03_核心类库_04_IO.zy2;
import java.io.IOException;
public class user {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        view v=new view();
        m: while (true) {
            v.welcome();
            int choose=v.menu();
            n: while (true) {
                if(choose==1) {
                    int choose2=v.managementMenu();
                    switch (choose2){
                        case 1:
                            v.save();
                            continue  ;
                        case 2:
                            v.delete();
                            continue  ;
                        case 3:
                            v.correction();
                            continue  ;
                        case 4:
                            v.chockAll();
                            continue  ;
                        case 5:
                            continue m;
                    }
                }
                if(choose==2)
                    v.user();
                if(choose==0)
                    break m;
            }
        }
        v.bye();
    }

}
