package D03_核心类库_04_IO.zy3;


import java.io.Serializable;
        import java.util.Objects;

public class Express implements Comparable<Express>, Serializable {
    private int number; //快递编号
    private String company; //快递公司
    private int code; //取件码

    public Express(int number, String company) {
        this.number = number;
        this.company = company;
    }

    public int getNumber() {
        return number;
    }

    public String getCompany() {
        return company;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Express express = (Express) o;
        return number == express.number;
    }

    @Override
    public int hashCode() {
        return Objects.hash(number);
    }


    @Override
    public int compareTo(Express o) {
        return Integer.compare(this.number, o.number);
    }
}

