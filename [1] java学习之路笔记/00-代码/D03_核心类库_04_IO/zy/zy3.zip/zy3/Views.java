package D03_核心类库_04_IO.zy3;

import java.util.Scanner;

/**
 * 作业:快递柜
 * 视图层
 */
public class Views {
    Scanner sca = new Scanner(System.in); //用于接收用户在控制台中的输入

    public Views() {
    }

    /**
     * 开机一级提示菜单,提示取件功能(普通用户)和管理员,并获取用户输入
     *
     * @return 用户的输入结果
     */
    public int menu1() {
        int num; //接收用户的输入
        while (true) {
            //提示信息
            System.out.println("\n欢迎使用");
            System.out.println("请选择功能,并输入功能编号:");
            System.out.println("1.取件");
            System.out.println("2.管理员功能");
            System.out.println("0.退出");
            //获取用户输入
            try {
                num = Integer.parseInt(sca.nextLine());
                //判断输入是否合法,若不合法则重新输入
                if (num < 0 || num > 2) {
                    System.out.println("\n输入信息有误,请根据提示重新输入");
                    continue;
                }
                //输入合法,返回用户的输入值
                return num;
            } catch (NumberFormatException e) {
                //若输入不合法导致转型失败,则重新输入
            }
        }
    }

    /**
     * 管理员菜单,提示管理员的各种功能,并获取用户的选择
     *
     * @return 用户的输入结果
     */
    public int administratorMenu() {
        int num; //接收用户的输入
        while (true) {
            //提示信息
            System.out.println("\n请选择功能,并输入功能编号:");
            System.out.println("1.快递录入");
            System.out.println("2.删除快递");
            System.out.println("3.修改快递");
            System.out.println("4.查看所有快递");
            System.out.println("0.返回上一级");
            //获取用户输入
            try {
                num = Integer.parseInt(sca.nextLine());
                //判断输入是否合法,若不合法则重新输入
                if (num < 0 || num > 4) {
                    System.out.println("\n输入信息有误,请根据提示重新输入");
                    continue;
                }
                //输入合法,返回用户的输入值
                return num;
            } catch (NumberFormatException e) {
                //若输入不合法导致转型失败,则重新输入
            }
        }
    }

    /**
     * 获取快递单号和快递公司
     *
     * @return 用户输入的快递单号和快递公司对应的快递
     */
    public Express getExpressNumberAndCompany() {
        int num; //接收用户输入的快递单号
        //获取快递单号
        while (true) {
            System.out.println("\n请输入快递单号:");
            try {
                num = Integer.parseInt(sca.nextLine());
                break;
            } catch (NumberFormatException e) {
                //若输入不合法导致转型失败,则重新输入
            }
        }
        //获取快递公司,并创建快递
        System.out.println("请输入快递公司:");
        return new Express(num, sca.nextLine());
    }

    /**
     * 输出快递信息,必须有取件码
     */
    public void showExpress(Express express) {
        if (express == null)
            noExpress();
        else
            System.out.println("\n快递信息:快递单号: " + express.getNumber()
                    + " 快递公司: " + express.getCompany()
                    + " 取件码: " + express.getCode());
    }

    /**
     * 快递柜中已经有该快递,输出错误提示信息
     */
    public void hasExpress() {
        System.out.println("\n该快递已经被存入,请核对快递单号");
    }

    /**
     * 快递柜已经满载,输出错误提示信息
     */
    public void alreadyFull() {
        System.out.println("\n快递柜已满,无法存入快递");
    }

    /**
     * 获取快递单号
     *
     * @return 用户输入的快递单号
     */
    public int getExpressNumber() {
        int num; //接收用户输入的快递单号
        //获取快递单号
        while (true) {
            System.out.println("\n请输入快递单号:");
            try {
                num = Integer.parseInt(sca.nextLine());
                return num;
            } catch (NumberFormatException e) {
                //若输入不合法导致转型失败,则重新输入
            }
        }
    }

    /**
     * 没有该快递,输出错误提示信息
     */
    public void noExpress() {
        System.out.println("\n没有该快递,请核对输入的快递信息");
    }

    /**
     * 操作成功(删除,修改),输出提示信息
     */
    public void success() {
        System.out.println("\n操作成功");
    }

    /**
     * 操作失败(删除,修改),输出提示信息
     */
    public void failed() {
        System.out.println("\n操作失败");
    }

    /**
     * 获取取件码
     *
     * @return 用户输入的取件码
     */
    public int getExpressCode() {
        int num; //接收用户输入的取件码
        //获取取件码
        while (true) {
            System.out.println("\n请输入取件码:");
            try {
                num = Integer.parseInt(sca.nextLine());
                return num;
            } catch (NumberFormatException e) {
                //若输入不合法导致转型失败,则重新输入
            }
        }
    }

    /**
     * 输出所有快递信息
     *
     * @param expresses 快递柜中的所有快递
     * @param num       快递柜中存入的快递数量
     */
    public void showAllExpress(Express[] expresses, int num) {
        if (expresses == null || num == 0) {
            lockerEmpty();
        } else {
            for (Express express : expresses) {
                if (express != null)
                    showExpress(express);
            }

        }
    }

    /**
     * 当前快递柜没有快递
     */
    public void lockerEmpty() {
        System.out.println("当前快递柜没有快递");
    }

    /**
     * 无法从数据文件中读取集合
     */
    public void errorRead() {
        System.out.println("数据文件损坏,无法从数据文件中读取集合");
    }

    /**
     * 无法将集合写入文件
     */
    public void errorWrite() {
        System.out.println("数据层结束错误,无法将集合写入文件");
    }
}


