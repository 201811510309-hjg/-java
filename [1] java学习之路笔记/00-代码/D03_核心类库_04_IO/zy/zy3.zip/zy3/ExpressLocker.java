package D03_核心类库_04_IO.zy3;

import java.io.*;
import java.util.Random;
import java.util.TreeSet;

public class ExpressLocker {
    private TreeSet<Express> expressSet;
    private static final String PATH = "express.txt"; //集合存储的文件路径
    private ObjectOutputStream oos;

    public ExpressLocker() throws IOException {
        File file = new File(PATH);
        if (file.exists()) {
            //数据文件存在,则从文件中读取集合
            try (ObjectInputStream ois = new ObjectInputStream((new FileInputStream(PATH)))) {
                expressSet = (TreeSet<Express>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                //无法从文件中读取集合
                e.printStackTrace();//输出错误的路径
                expressSet = new TreeSet<>();
                throw new IOException("无法从数据文件中读取集合");
            }
        } else
            //数据文件不存在,则创建空的集合
            expressSet = new TreeSet<>();

    }

    /**
     * 关机操作
     */
    public void close() throws IOException {
        this.write();
        oos.close();
    }

    /**
     * 将集合写入文件
     *
     * @throws IOException 无法写入数据文件,或者输出流初始化失败
     */
    public void write() throws IOException {
        //如果输出流未被初始化,则证明是第一次写入,对输出流进行初始化
        if (oos == null) {
            oos = new ObjectOutputStream(new FileOutputStream(PATH));//这个位置我写的错误
        }
        //写入对象
        oos.writeObject(expressSet);
    }

    /**
     * 根据快递单号查询快递
     *
     * @param expressNumber 快递单号
     * @return 若有则返回查询到的快递, 若没有则返回null
     */
    public Express findByNumber(int expressNumber) {
        for (Express e : expressSet) {
            if (e.getNumber() == expressNumber)
                return e;
        }
        return null;
    }

    /**
     * 根据快递单号查询快递
     *
     * @param expressCode 快递取件码
     * @return 若有则返回查询到的快递, 若没有则返回null
     */
    public Express findByCode(int expressCode) {
        for (Express e : expressSet) {
            if (e.getCode() == expressCode)
                return e;
        }
        return null;
    }

    /**
     * 添加快递
     *
     * @param express 待添加的快递
     * @return 添加结果
     */
    public boolean add(Express express) throws IOException {
        if (express == null)
            return false;
        //生成取件码
        express.setCode(genCode());
        //添加快递
        final boolean b = expressSet.add(express);
        if (b)
            this.write();
        return b;
    }

    /**
     * 生成100000-999999之间的取件码
     *
     * @return 取件码
     */
    public int genCode() {
        int num; //接收系统生成的随机数
        Random random = new Random();
        do {
            num = random.nextInt(900000) + 100000;
            //如果快递柜中没有该取件码的快递,证明新生成的取件码有效
        } while (findByCode(num) != null);
        return num;
    }
    /**
     * 删除快递
     * @param express 待删除的快递
     * @return 删除结果
     */
    public boolean delete(Express express) throws IOException {
        final boolean b = expressSet.remove(express);
        if (b)
            this.write();//删除成功就写出
        return b;
    }

    public Express[] getExpresses() {
        return expressSet.toArray(new Express[this.getSize()]);
    }

    public int getSize() {
        return expressSet.size();
    }

}


