package D03_核心类库_04_IO.zy3;

import java.io.IOException;

/**
 * 作业
 * 快递柜
 * 调度层
 */
public class Main {
    static Views views = new Views(); //视图层
    static ExpressLocker locker;
    static {
        try {
            locker = new ExpressLocker();
        } catch (IOException e) {
            views.errorRead();
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        int i1; //接收用户的输入
        Loop1:
        while (true) {
            //开机总控流程
            //开始菜单
            i1 = views.menu1();
            switch (i1) {
                case 1:
                    //取件
                    user();
                    break;
                case 2:
                    //管理员功能
                    administrator();
                    break;
                case 0:
                    //退出
                    try {
                        locker.close();
                    } catch (IOException e) {
                        views.errorWrite();
                        e.printStackTrace();
                    }
                    break Loop1;
            }
        }

    }

    /**
     * 管理员的操作流程
     */
    public static void administrator() {
        int i1; //接收用户的输入
        while (true) {
            i1 = views.administratorMenu();
            switch (i1) {
                case 0:
                    //返回上一级
                    return;
                case 1:
                    //快递录入
                    addExpress();
                    break;
                case 2:
                    //删除快递
                    deleteExpress();
                    break;
                case 3:
                    //修改快递
                    changeExpress();
                    break;
                case 4:
                    //查看所有快递
                {
                    Express[] expresses = locker.getExpresses();
//                    int num = locker.getIndex();//当前存入的快递数量
                    int num = locker.getSize();//getSize是一个方法，返回值是集合的大小
                    views.showAllExpress(expresses, num);
                }
            }
        }
    }

    /**
     * 快递录入
     */
    public static void addExpress() {
        //输出提示信息,并接收快递单号和快递公司
        Express express = views.getExpressNumberAndCompany();
        //查询快递单号,是否已经存入该快递
        if (locker.findByNumber(express.getNumber()) == null) {
            //没有该快递,可以存入
            try {
                if (locker.add(express)) {
                    //存入成功,输出快递信息
                    views.showExpress(express);
                } else {
                    //存入失败,快递柜已经满载
                    views.alreadyFull();
                }
            } catch (IOException e) {
                views.errorWrite();
                e.printStackTrace();
            }
        } else {
            //已经有该快递
            views.hasExpress();
        }
    }

    /**
     * 删除快递
     */
    public static void deleteExpress() {
        //输出提示并获取快递单号
        int number = views.getExpressNumber();
        //查询是否有该快递
        Express express = locker.findByNumber(number);
        if (express == null) {
            //没有该快递
            views.noExpress();
        } else {
            //有该快递,则删除该快递
            try {
                if (locker.delete(express)) {
                    //操作成功
                    views.success();
                } else {
                    //操作失败
                    views.failed();
                }
            } catch (IOException e) {
                views.errorWrite();
                e.printStackTrace();
            }
        }
    }

    /**
     * 修改快递
     */
    public static void changeExpress() {
        //输出提示并获取快递单号
        int number = views.getExpressNumber();
        //查询是否有该快递
        Express express = locker.findByNumber(number);
        if (express == null) {
            //没有该快递
            views.noExpress();
        } else {
            //有该快递,则输出提示信息,并接收新的快递单号和快递公司
            Express expressNew = views.getExpressNumberAndCompany();
            //删除旧快递
            try {
                if (locker.delete(express)) {
                    //操作成功
                    locker.add(expressNew);
                    views.success();
                } else {
                    //操作失败
                    views.failed();
                }
            } catch (IOException e) {
                views.errorWrite();
                e.printStackTrace();
            }
        }

    }

    /**
     * 普通用户的操作流程
     */
    public static void user() {
        //输出提示信息,并接收取件码
        int expressCode = views.getExpressCode();
        //查询是否有该快递
        Express express = locker.findByCode(expressCode);
        if (express != null) {
            //有该快递
            views.showExpress(express);
            //从快递柜中删除该快递
            try {
                locker.delete(express);
            } catch (IOException e) {
                views.errorWrite();
                e.printStackTrace();
            }
        } else {
            //没有该快递
            views.noExpress();
        }
    }
}


